from googleapiclient.discovery import build
import os
from google.cloud import storage
#API_KEY = os.environ.get("API_KEY")

"""
youtube = build("youtube", "v3", developerKey=API_KEY)
request = youtube.channels().list(part="statistics", forUsername="ElRichMC")
response = request.execute()
"""

def implicit():
    # If you don't specify credentials when constructing the client, the
    # client library will look for credentials in the environment.
    storage_client = storage.Client()

    # Make an authenticated API request
    buckets = list(storage_client.list_buckets())
    print(buckets)

implicit()